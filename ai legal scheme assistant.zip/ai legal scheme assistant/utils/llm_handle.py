
def explain_scheme(user_query):
    if not user_query:
        return "Please ask a valid question."

    query = user_query.lower()

    if "pm kisan" in query:
        return """PM Kisan Scheme:
Eligible farmers receive ₹6000 per year in three installments.
Eligibility:
- Small or marginal farmer
- Land up to 2 hectares
Apply at: pmkisan.gov.in"""

    elif "scholarship" in query:
        return """National Scholarship Portal:
For students from low-income families.
Income must be below ₹2.5 lakhs.
Apply at: scholarships.gov.in"""

    elif "salary" in query or "wage" in query:
        return """Under the Payment of Wages Act, 1936:
Employers must pay salary on time.
If salary is not paid, you can complain to Labour Commissioner."""

    else:
        return """I can help with:
- PM Kisan Scheme
- Scholarships
- Mudra Loan
- Salary legal issues"""
