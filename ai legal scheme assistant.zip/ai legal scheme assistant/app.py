from flask import Flask, render_template, request, jsonify
from eligibility_engine import check_eligibility
from utils.llm_handle import explain_scheme

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/eligibility", methods=["POST"])
def eligibility():
    data = request.json

    user_profile = {
        "occupation": data.get("occupation"),
        "income": int(data.get("income", 0)),
        "land": float(data.get("land", 0))
    }

    results = check_eligibility(user_profile)

    return jsonify(results)


@app.route("/ask", methods=["POST"])
def ask():
    data = request.json
    question = data.get("question")

    answer = explain_scheme(question)

    return jsonify({"response": answer})


if __name__ == "__main__":
    print("Starting Flask Server...")
    app.run(host="127.0.0.1", port=5000, debug=True)
