async function checkEligibility() {
    const occupation = document.getElementById("occupation").value;
    const income = document.getElementById("income").value;
    const land = document.getElementById("land").value;

    const response = await fetch("/eligibility", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({occupation, income, land})
    });

    const data = await response.json();

    let output = "<h3>Eligible Schemes:</h3>";
    if (data.length === 0) {
        output += "No matching schemes found.";
    } else {
        data.forEach(scheme => {
            output += `<p><b>${scheme.name}</b>: ${scheme.description}</p>`;
        });
    }

    document.getElementById("eligibility_result").innerHTML = output;
}

async function askQuestion() {
    const question = document.getElementById("question").value;
    const language = document.getElementById("language").value;

    const response = await fetch("/ask", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({question, language})
    });

    const data = await response.json();
    document.getElementById("chat_result").innerText = data.response;
}
