schemes = {
    "PM Kisan": {
        "description": "Provides ₹6000 per year to eligible farmers in 3 installments.",
        "eligibility": {
            "occupation": "farmer",
            "max_land_hectares": 2
        }
    },
    "NSP Scholarship": {
        "description": "Scholarship for students from low-income families.",
        "eligibility": {
            "occupation": "student",
            "max_income": 250000
        }
    },
    "Mudra Loan": {
        "description": "Loan support for small businesses and MSMEs.",
        "eligibility": {
            "occupation": "business",
            "max_income": 1000000
        }
    }
}
