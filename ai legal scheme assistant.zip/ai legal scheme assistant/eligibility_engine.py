from scheme_data import schemes

def check_eligibility(user_profile):
    eligible_schemes = []

    for name, details in schemes.items():
        eligibility = details["eligibility"]

        occupation_match = user_profile["occupation"] == eligibility.get("occupation")

        income_match = True
        if "max_income" in eligibility:
            income_match = user_profile["income"] <= eligibility["max_income"]

        land_match = True
        if "max_land_hectares" in eligibility:
            land_match = user_profile["land"] <= eligibility["max_land_hectares"]

        if occupation_match and income_match and land_match:
            eligible_schemes.append({
                "name": name,
                "description": details["description"]
            })

    return eligible_schemes
